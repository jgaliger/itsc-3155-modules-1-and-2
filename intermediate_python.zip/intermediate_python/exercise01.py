my_list=[]
placeholder = 0
while True:
    num = 0
    num = (input('Please enter a number or QUIT to quit: '))
    if num != 'QUIT':
        my_list.append(int(num))
        placeholder +=1
        continue
    else:
        break



def unique_list_method(input_list):
    unique_list = []
    for item in input_list:
        if item not in unique_list:
            unique_list.append(item)
    print(unique_list)
unique_list_method(my_list)
print(my_list)