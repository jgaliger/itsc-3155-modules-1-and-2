print("Please enter 5 ints")
my_list =[]
while True:
    try: 
        value = input("Please enter your int here or type stop: ")
        if value == 'stop':
            break
        my_list.append(value)
    except ValueError:
        print("You have entered a non-integer. Please try again. ")

num = 0
for value in my_list:
    num += int(value)
print("Your final value is " + str(num))

    