string1 = input("Please enter a word: ")
my_dict = {}

def lowercaseCounter(input):
    
    for char in input:
        char = char.lower()
        if char == ' ':
            print(" ")
        elif char in my_dict:
            my_dict[char] += 1
        else:
            my_dict[char] = 1
    print(my_dict)

lowercaseCounter(string1)
    