my_dict_1 = {}
my_dict_2 = {}
print("THIS IS THE FIRST DICT")
while True:
    value1 = input("Please enter a key: ")
    value2 = int(input("Please enter a value: "))
    print("If you would like to quit type stop in the key slot and still enter a value")
    if value1 != 'stop':
        my_dict_1[value1] = value2
    else:
        break
print("THIS IS NOW THE SECOND DICT")
while True:
    value1 = input("Please enter a key: ")
    value2 = int(input("Please enter a value: "))
    print("If you would like to quit type stop in the key slot and still enter a value")
    if value1 != 'stop':
        my_dict_2[value1] = value2
    else:
        break   
def get_combined_dict(dict_1,dict_2):
    combined_dict = {}
    for key in dict_1:
        if key not in combined_dict:
            combined_dict[key] += 0
        else:
            combined_dict[key] += dict_1[key]
    for key in dict_2:
        if key not in combined_dict:
            combined_dict[key] +=0
        else:
            combined_dict[key] += dict_2[key]
    print(combined_dict)
get_combined_dict(my_dict_1,my_dict_2)
print(my_dict_1)
print(my_dict_2)
