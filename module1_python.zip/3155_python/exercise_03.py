number = int(input('Please enter a number greater than 1: '))

for x in range(0, number+1):
    print('The cube of ' + str(x) + ' is ' + str(x*x*x))

    