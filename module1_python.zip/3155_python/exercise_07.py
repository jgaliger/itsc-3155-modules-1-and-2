my_list = []
placeholder = 0
while True:
    num = 0
    num = (input('Please enter a number or QUIT to quit: '))
    if num != 'QUIT':
        my_list.append(int(num))
        placeholder +=1
        continue
    else:
        break
print('The list values are: ')
for x in range(0,placeholder):
    print(my_list[x])


