print('Please enter two strings: ')
string1 = input('The first string: ')
string2 = input('The second string: ')
if string1 == string2:
    print('They are the same')
else:
    print('They are not the same')
