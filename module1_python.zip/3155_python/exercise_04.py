number = int(input('Please enter a number: '))
my_list = [0]*number
for x in range(0,number):
    my_list[x] = float(input('Please enter float ' + str(x+1) +": "))

for x in range(0,number):
    print('Value ' + str(x+1) + ': ' + str(my_list[x]))
newNumber = 0
for x in range(0,number):
    newNumber += my_list[x]

print('This is the average: ' + str(newNumber/number))

