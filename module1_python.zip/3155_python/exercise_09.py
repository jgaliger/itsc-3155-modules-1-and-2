print('Please enter five words: ')

my_list = []
for x in range(0,5):
    my_list.append(input('Enter here: '))
print('Words: ')
for x in range(0,5):
    print(my_list[x] + ', ')