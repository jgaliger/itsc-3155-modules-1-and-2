print('Please enter 10 integers')

my_list = [0,0,0,0,0,0,0,0,0,0]
repeat_list = []

repeatCounter = 0
for x in range(0,10):
   my_list[x] = int(input(str(x+1) + ': '))
for x in range(0,10):
    for y in range(0,10):
        if my_list[x] == my_list[y]:
            print(end='')
        else:
            repeat_list.append(my_list[x])

for x in range(0,10):
    print('Repeated values: ' + str(x+1) + ': ' + str(repeat_list[x]))

    