print('Please enter five integers')
my_list = [0,0,0,0,0]
my_new_list = [0,0,0,0,0]
common_list = [0,0,0,0,0]
for x in range(0,5):
    my_list[x] = float(input('Number ' + str(x+1) +": "))
print('Please enter five more integers')

for x in range(0,5):
    my_new_list[x] = float(input('Number ' + str(x+1) +": "))

for x in range(0,5):
    print('List 1 value ' + str(x+1) + ': ' + str(my_list[x]))
for x in range(0,5):
    print('List 2 value ' + str(x+1) + ': ' + str(my_new_list[x]))

for x in range(0,5):
    for j in range(0,5):
        if my_list[x] == my_new_list[j]:
            for z in range(0,5):
                if common_list[z] == my_list[x]:
                    print('The value is already there.')
                else:
                    common_list[x] = my_list[x]
                    

for x in range(0,5):
    print('List 2 value ' + str(x+1) + ': ' + str(common_list[x]))