grade = int(input('Please enter your grade: '))
if grade > 100 or grade < 0:
    print('Please enter a grade in the range of 0-100')
elif grade < 60:
    print('Your grade is an D')
elif grade < 70:
    print('Your grade is an D')
elif grade < 80:
    print('Your grade is an C')
elif grade < 90:
    print('Your grade is an B')
elif grade <= 100:
    print('Your grade is an A')
else:
    print('Please enter a grade in the range of 0-100')